package com.kubera.scanner.percentageview.callback;

public interface OnProgressChangeListener {

    void onProgressChanged(float progress);

}
