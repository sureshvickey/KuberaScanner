package com.kubera.scanner.utils;

public interface FragmentCommunicator {
    public void passData(String name);
}
